package za.ac.tut.web;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.ejb.EJB;
import java.text.SimpleDateFormat;
import za.ac.tut.model.entity.DentistAppointment;
import za.ac.tut.model.business.DentistAppointmentFacade;

public class AddAppointmentServlet extends HttpServlet {
    @EJB
    private DentistAppointmentFacade facade;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            DentistAppointment app = new DentistAppointment();
            app.setName(request.getParameter("name"));
            app.setEmail(request.getParameter("email"));
            app.setDate(new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("date")));
            app.setTime(request.getParameter("time"));
            app.setDescription(request.getParameter("description"));
            app.setStatus(request.getParameter("status"));

            facade.create(app);
            response.sendRedirect("add_outcome.html");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
