package za.ac.tut.model.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

@Entity
public class DentistAppointment implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    private String email;
    @Temporal(TemporalType.DATE)
    private Date date;
    private String time;
    private String description;
    private String status;

    // Getters and setters omitted for brevity
}
