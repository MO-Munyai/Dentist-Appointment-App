package za.ac.tut.model.business;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import za.ac.tut.model.entity.DentistAppointment;
import java.util.List;

@Stateless
public class DentistAppointmentFacade {
    @PersistenceContext(unitName = "DentistPU")
    private EntityManager em;

    public void create(DentistAppointment appointment) {
        em.persist(appointment);
    }

    public List<DentistAppointment> findAll() {
        return em.createQuery("SELECT d FROM DentistAppointment d", DentistAppointment.class).getResultList();
    }
}
