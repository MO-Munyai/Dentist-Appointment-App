
package za.ac.tut.servlet;

import za.ac.tut.entity.Appointment;
import za.ac.tut.bl.AppointmentFacadeLocal;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/listAppointments")
public class ListAppointmentsServlet extends HttpServlet {

    @EJB
    private AppointmentFacadeLocal appointmentFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Appointment> appointments = appointmentFacade.findAll();
        request.setAttribute("appointments", appointments);
        request.getRequestDispatcher("list_appointments.jsp").forward(request, response);
    }
}
