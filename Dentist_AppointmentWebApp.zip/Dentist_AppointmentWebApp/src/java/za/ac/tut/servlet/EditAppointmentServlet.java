
package za.ac.tut.servlet;

import za.ac.tut.entity.Appointment;
import za.ac.tut.bl.AppointmentFacadeLocal;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/editAppointment")
public class EditAppointmentServlet extends HttpServlet {

    @EJB
    private AppointmentFacadeLocal appointmentFacade;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        String patient = request.getParameter("patient");
        String dentist = request.getParameter("dentist");
        String date = request.getParameter("date");

        Appointment appointment = appointmentFacade.find(id);
        appointment.setPatient(patient);
        appointment.setDentist(dentist);
        appointment.setDate(date);

        appointmentFacade.edit(appointment);

        response.sendRedirect("list_appointments.jsp");
    }
}
