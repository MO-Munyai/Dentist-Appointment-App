
package za.ac.tut.servlet;

import za.ac.tut.entity.Appointment;
import za.ac.tut.bl.AppointmentFacadeLocal;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/deleteAppointment")
public class DeleteAppointmentServlet extends HttpServlet {

    @EJB
    private AppointmentFacadeLocal appointmentFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        Appointment appointment = appointmentFacade.find(id);
        appointmentFacade.remove(appointment);

        response.sendRedirect("list_appointments.jsp");
    }
}
